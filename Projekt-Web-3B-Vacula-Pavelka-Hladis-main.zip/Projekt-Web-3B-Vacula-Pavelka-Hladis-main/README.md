=======
# Dokumentace 
## Členové týmu: Vacula, Pavelka, Hladiš
## Konvence pro názvy
### Databáze: 
* česky
* jednotné číslo, všechno malým písmenem
* snake case (př. nazev_databaze)
### Názvy Modelů, kontrolerů a knihoven:
* česky
* pascal case (př. NazevModelu)
### Názvy Views:
* česky
* camel case (př. hlavniStrana)
### Názvy ostatních tříd, metod a proměnných:
* česky
* camel case (př. nazevTridy)
##  Assets & Šablony
- **Složka `assets` a soubory `template` a `layout` jsou malými písmeny**
